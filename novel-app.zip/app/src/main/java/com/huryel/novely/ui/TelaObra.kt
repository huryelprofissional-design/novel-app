package com.huryel.novely.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.huryel.novely.NovelyApp
import com.huryel.novely.data.Capitulo
import com.huryel.novely.data.Obra
import com.huryel.novely.data.StatusObra
import com.huryel.novely.data.Volume
import com.huryel.novely.ui.theme.LocalPaleta
import kotlinx.coroutines.launch

private sealed interface Dialogo {
    data object EditarInfo : Dialogo
    data object NovoCapitulo : Dialogo
    data object NovoVolume : Dialogo
    data object ExcluirObra : Dialogo
    data class RenomearCap(val c: Capitulo) : Dialogo
    data class ExcluirCap(val c: Capitulo) : Dialogo
    data class MoverCap(val c: Capitulo) : Dialogo
    data class RenomearVol(val v: Volume) : Dialogo
    data class ExcluirVol(val v: Volume) : Dialogo
    data class MenuImagem(val tipo: String) : Dialogo
}

@Composable
fun TelaObra(obraId: Long, nav: NavHostController) {
    val repo = NovelyApp.instancia.repo
    val p = LocalPaleta.current
    val escopo = rememberCoroutineScope()
    val obra by remember(obraId) { repo.obra(obraId) }.collectAsState(initial = null)
    val volumes by remember(obraId) { repo.volumes(obraId) }.collectAsState(initial = emptyList())
    val capitulos by remember(obraId) { repo.capitulos(obraId) }.collectAsState(initial = emptyList())
    var dialogo by remember { mutableStateOf<Dialogo?>(null) }
    var menuObra by remember { mutableStateOf(false) }
    var tipoEscolhendo by remember { mutableStateOf("capa") }
    val snack = remember { SnackbarHostState() }

    val seletor = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) escopo.launch {
            val ok = repo.trocarImagem(obraId, tipoEscolhendo, uri)
            if (ok) nav.navigate("imagem/$obraId/$tipoEscolhendo")
            else snack.showSnackbar("Não consegui abrir essa imagem.")
        }
    }
    fun escolherImagem(tipo: String) {
        tipoEscolhendo = tipo
        seletor.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    val o = obra ?: run { Box(Modifier.fillMaxSize()); return }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 40.dp)) {
            item { Cabecalho(o, nav, aoMenu = { menuObra = true }, aoBanner = { dialogo = Dialogo.MenuImagem("banner") }, aoCapa = { dialogo = Dialogo.MenuImagem("capa") }) }
            item {
                Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (o.descricao.isNotBlank()) Text(o.descricao, color = p.textoSuave, fontSize = 14.sp, lineHeight = 21.sp)
                    val total = capitulos.size
                    val palavras = capitulos.sumOf { it.palavras.toLong() }
                    val lidos = capitulos.count { it.progresso >= 0.98f }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Estatistica("$total", "capítulos", Modifier.weight(1f))
                        Estatistica(formatarPalavras(palavras), "palavras", Modifier.weight(1f))
                        Estatistica(if (total > 0) "${lidos * 100 / total}%" else "—", "lido", Modifier.weight(1f))
                    }
                    val alvo = capitulos.firstOrNull { it.id == o.ultimoCapituloId } ?: capitulos.firstOrNull { it.progresso < 0.98f } ?: capitulos.firstOrNull()
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { alvo?.let { nav.navigate("leitor/${it.id}") } },
                            enabled = alvo != null,
                            colors = ButtonDefaults.buttonColors(p.destaque, p.sobreDestaque),
                            shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f).height(52.dp),
                        ) {
                            Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp))
                            Text(if (alvo == null) "Sem capítulos" else "Ler · ${alvo.titulo}", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        OutlinedButton(
                            onClick = { dialogo = Dialogo.NovoCapitulo },
                            shape = RoundedCornerShape(16.dp), modifier = Modifier.height(52.dp),
                        ) { Text("+ Capítulo") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Capítulos", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        TextButton(onClick = { dialogo = Dialogo.NovoVolume }) { Text("+ Volume / arco") }
                    }
                }
            }

            val semVolume = capitulos.filter { c -> c.volumeId == null || volumes.none { it.id == c.volumeId } }
            if (semVolume.isNotEmpty() && volumes.isNotEmpty()) item { CabecalhoVolume("Sem volume", null, {}, {}) }
            items(semVolume, key = { "c${it.id}" }) { c -> LinhaCapitulo(c, o, nav, { dialogo = it }, escopo) }
            volumes.forEach { v ->
                item(key = "v${v.id}") { CabecalhoVolume(v.titulo, v, { dialogo = Dialogo.RenomearVol(v) }, { dialogo = Dialogo.ExcluirVol(v) }) }
                val dele = capitulos.filter { it.volumeId == v.id }
                if (dele.isEmpty()) item(key = "vazio${v.id}") {
                    Text("Nenhum capítulo aqui. Use ⋮ › Mover para volume.", color = p.textoSuave, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                }
                items(dele, key = { "c${it.id}" }) { c -> LinhaCapitulo(c, o, nav, { dialogo = it }, escopo) }
            }
            if (capitulos.isEmpty()) item {
                Text("Nenhum capítulo ainda. Toque em “+ Capítulo” para começar.", color = p.textoSuave, modifier = Modifier.padding(20.dp))
            }
        }

        Box(Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp)) {
            DropdownMenu(expanded = menuObra, onDismissRequest = { menuObra = false }) {
                DropdownMenuItem(text = { Text("Editar título e descrição") }, onClick = { menuObra = false; dialogo = Dialogo.EditarInfo })
                DropdownMenuItem(text = { Text("Trocar capa") }, onClick = { menuObra = false; escolherImagem("capa") })
                DropdownMenuItem(text = { Text("Trocar banner") }, onClick = { menuObra = false; escolherImagem("banner") })
                HorizontalDivider()
                listOf(StatusObra.ESCREVENDO, StatusObra.LENDO, StatusObra.CONCLUIDA).forEach { s ->
                    DropdownMenuItem(
                        text = { Text("Marcar como ${nomeStatus(s).lowercase()}") },
                        leadingIcon = { if (o.status == s) Icon(Icons.Filled.Check, null) },
                        onClick = { menuObra = false; escopo.launch { repo.salvarObra(o.copy(status = s)) } },
                    )
                }
                HorizontalDivider()
                DropdownMenuItem(text = { Text("Excluir obra", color = Color(0xFFE57373)) }, onClick = { menuObra = false; dialogo = Dialogo.ExcluirObra })
            }
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter))
    }

    when (val d = dialogo) {
        null -> {}
        Dialogo.EditarInfo -> DialogoInfo(o, aoFechar = { dialogo = null }) { t, desc ->
            dialogo = null; escopo.launch { repo.salvarObra(o.copy(titulo = t.trim().ifEmpty { o.titulo }, descricao = desc.trim())) }
        }
        Dialogo.NovoCapitulo -> DialogoTexto("Novo capítulo", "Título", "Capítulo ${capitulos.size + 1}", "Criar", aoFechar = { dialogo = null }) { t ->
            dialogo = null
            escopo.launch {
                val volume = capitulos.lastOrNull()?.volumeId
                val id = repo.novoCapitulo(obraId, t, volume)
                if (o.status == StatusObra.ESCREVENDO) nav.navigate("editor/$id")
            }
        }
        Dialogo.NovoVolume -> DialogoTexto("Novo volume ou arco", "Nome", "Volume ${volumes.size + 1}", "Criar", aoFechar = { dialogo = null }) { t ->
            dialogo = null; escopo.launch { repo.novoVolume(obraId, t) }
        }
        Dialogo.ExcluirObra -> DialogoConfirmar("Excluir “${o.titulo}”?", "Todos os ${capitulos.size} capítulos e textos serão apagados deste aparelho. Isso não pode ser desfeito.", "Excluir tudo", { dialogo = null }) {
            dialogo = null; escopo.launch { repo.excluirObra(o); nav.popBackStack() }
        }
        is Dialogo.RenomearCap -> DialogoTexto("Renomear capítulo", "Título", d.c.titulo, aoFechar = { dialogo = null }) { t ->
            dialogo = null; escopo.launch { repo.salvarCapitulo(d.c.copy(titulo = t.trim().ifEmpty { d.c.titulo })) }
        }
        is Dialogo.ExcluirCap -> DialogoConfirmar("Excluir “${d.c.titulo}”?", "O texto deste capítulo será apagado.", "Excluir", { dialogo = null }) {
            dialogo = null; escopo.launch { repo.excluirCapitulo(d.c) }
        }
        is Dialogo.MoverCap -> AlertDialog(
            onDismissRequest = { dialogo = null },
            title = { Text("Mover para…") },
            text = {
                Column {
                    (listOf<Volume?>(null) + volumes).forEach { v ->
                        Text(v?.titulo ?: "Sem volume", fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable {
                            dialogo = null; escopo.launch { repo.salvarCapitulo(d.c.copy(volumeId = v?.id)) }
                        }.padding(vertical = 14.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialogo = null }) { Text("Fechar") } },
        )
        is Dialogo.RenomearVol -> DialogoTexto("Renomear volume", "Nome", d.v.titulo, aoFechar = { dialogo = null }) { t ->
            dialogo = null; escopo.launch { repo.renomearVolume(d.v, t) }
        }
        is Dialogo.ExcluirVol -> DialogoConfirmar("Excluir “${d.v.titulo}”?", "Os capítulos NÃO serão apagados: eles vão para “Sem volume”.", "Excluir volume", { dialogo = null }) {
            dialogo = null; escopo.launch { repo.excluirVolume(d.v) }
        }
        is Dialogo.MenuImagem -> {
            val nome = if (d.tipo == "banner") "banner" else "capa"
            val tem = if (d.tipo == "banner") o.banner != null else o.capa != null
            AlertDialog(
                onDismissRequest = { dialogo = null },
                title = { Text(nome.replaceFirstChar { it.uppercase() }) },
                text = {
                    Column {
                        listOfNotNull(
                            "Escolher imagem da galeria" to { escolherImagem(d.tipo) },
                            if (tem) "Ajustar enquadramento" to { nav.navigate("imagem/$obraId/${d.tipo}") } else null,
                            if (tem) "Remover imagem" to { escopo.launch { repo.removerImagem(obraId, d.tipo) }; Unit } else null,
                        ).forEach { (rotulo, acao) ->
                            Text(rotulo, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { dialogo = null; acao() }.padding(vertical = 14.dp))
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { dialogo = null }) { Text("Fechar") } },
            )
        }
    }
}

@Composable
private fun Cabecalho(o: Obra, nav: NavHostController, aoMenu: () -> Unit, aoBanner: () -> Unit, aoCapa: () -> Unit) {
    val p = LocalPaleta.current
    Box(Modifier.fillMaxWidth().height(300.dp)) {
        ImagemEnquadrada(o.banner, o.bannerX, o.bannerY, o.bannerZoom, o.corBase,
            Modifier.fillMaxWidth().height(210.dp).clickable(onClick = aoBanner), ladoMax = 1400) {
            Text("Toque para colocar um banner", color = Color(0x99FFFFFF), fontSize = 13.sp, modifier = Modifier.align(Alignment.Center))
        }
        Box(Modifier.fillMaxWidth().height(210.dp).background(Brush.verticalGradient(0.45f to Color.Transparent, 1f to p.fundo)))
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            BotaoRedondo({ Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }) { nav.popBackStack() }
            BotaoRedondo({ Icon(Icons.Filled.MoreVert, "Opções da obra") }, aoMenu)
        }
        Row(Modifier.align(Alignment.BottomStart).padding(horizontal = 20.dp), verticalAlignment = Alignment.Bottom) {
            CapaObra(o.titulo, o.capa, o.capaX, o.capaY, o.capaZoom, o.corBase,
                Modifier.width(110.dp).height(160.dp).border(2.dp, p.fundo, RoundedCornerShape(12.dp)).clickable(onClick = aoCapa), 13.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.padding(bottom = 6.dp)) {
                Text(nomeStatus(o.status).uppercase(), style = MaterialTheme.typography.labelSmall, color = p.destaque)
                Text(o.titulo, style = MaterialTheme.typography.headlineSmall.copy(fontSize = 24.sp, lineHeight = 27.sp), maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
        }
    }
    Spacer(Modifier.height(16.dp))
}

@Composable
private fun BotaoRedondo(icone: @Composable () -> Unit, aoTocar: () -> Unit) {
    Box(Modifier.size(44.dp).clip(RoundedCornerShape(22.dp)).background(Color(0x99000000)).clickable(onClick = aoTocar), contentAlignment = Alignment.Center) {
        CompositionLocalProvider(LocalContentColor provides Color.White) { icone() }
    }
}

@Composable
private fun Estatistica(valor: String, rotulo: String, modifier: Modifier) {
    val p = LocalPaleta.current
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(p.superficie).padding(10.dp)) {
        Text(valor, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(rotulo, color = p.textoSuave, fontSize = 12.sp)
    }
}

@Composable
private fun CabecalhoVolume(titulo: String, v: Volume?, aoRenomear: () -> Unit, aoExcluir: () -> Unit) {
    val p = LocalPaleta.current
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(titulo.uppercase(), style = MaterialTheme.typography.labelSmall, color = p.destaque, modifier = Modifier.weight(1f))
        if (v != null) Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Opções do volume", tint = p.textoSuave) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Renomear") }, onClick = { menu = false; aoRenomear() })
                DropdownMenuItem(text = { Text("Excluir volume") }, onClick = { menu = false; aoExcluir() })
            }
        }
    }
}

@Composable
private fun LinhaCapitulo(c: Capitulo, o: Obra, nav: NavHostController, abrir: (Dialogo) -> Unit, escopo: kotlinx.coroutines.CoroutineScope) {
    val repo = NovelyApp.instancia.repo
    val p = LocalPaleta.current
    var menu by remember { mutableStateOf(false) }
    val atual = c.id == o.ultimoCapituloId
    val lido = c.progresso >= 0.98f
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp).clip(RoundedCornerShape(14.dp))
            .background(if (atual) p.superficie else Color.Transparent)
            .clickable { nav.navigate("leitor/${c.id}") }.padding(start = 10.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(c.titulo, fontSize = 15.sp, fontWeight = if (atual) FontWeight.Bold else FontWeight.Normal,
                color = if (lido && !atual) p.textoSuave else p.texto, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${formatarPalavras(c.palavras.toLong())} palavras", fontSize = 12.sp, color = p.textoSuave)
                if (c.rascunho && o.status == StatusObra.ESCREVENDO) Text("RASCUNHO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6FC2B4))
                if (c.progresso in 0.01f..0.979f) Text("${(c.progresso * 100).toInt()}%", fontSize = 12.sp, color = p.destaque, fontWeight = FontWeight.Bold)
                if (lido) Icon(Icons.Filled.Check, "Lido", tint = p.textoSuave, modifier = Modifier.size(14.dp))
            }
        }
        IconButton(onClick = { nav.navigate("editor/${c.id}") }) { Icon(Icons.Filled.Edit, "Editar texto", tint = p.textoSuave) }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Opções do capítulo", tint = p.textoSuave) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Renomear") }, onClick = { menu = false; abrir(Dialogo.RenomearCap(c)) })
                DropdownMenuItem(text = { Text(if (c.rascunho) "Marcar como concluído" else "Voltar para rascunho") },
                    onClick = { menu = false; escopo.launch { repo.salvarCapitulo(c.copy(rascunho = !c.rascunho)) } })
                DropdownMenuItem(text = { Text(if (lido) "Marcar como não lido" else "Marcar como lido") },
                    onClick = { menu = false; escopo.launch { repo.salvarCapitulo(c.copy(progresso = if (lido) 0f else 1f)) } })
                DropdownMenuItem(text = { Text("Subir") }, onClick = { menu = false; escopo.launch { repo.moverCapitulo(c, -1) } })
                DropdownMenuItem(text = { Text("Descer") }, onClick = { menu = false; escopo.launch { repo.moverCapitulo(c, 1) } })
                DropdownMenuItem(text = { Text("Mover para volume") }, onClick = { menu = false; abrir(Dialogo.MoverCap(c)) })
                HorizontalDivider()
                DropdownMenuItem(text = { Text("Excluir", color = Color(0xFFE57373)) }, onClick = { menu = false; abrir(Dialogo.ExcluirCap(c)) })
            }
        }
    }
}

@Composable
private fun DialogoInfo(o: Obra, aoFechar: () -> Unit, aoSalvar: (String, String) -> Unit) {
    var titulo by remember { mutableStateOf(o.titulo) }
    var desc by remember { mutableStateOf(o.descricao) }
    AlertDialog(
        onDismissRequest = aoFechar,
        title = { Text("Editar obra") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(titulo, { titulo = it }, label = { Text("Título") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(desc, { desc = it }, label = { Text("Descrição / sinopse") }, minLines = 4, maxLines = 8, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(onClick = { aoSalvar(titulo, desc) }) { Text("Salvar") } },
        dismissButton = { TextButton(onClick = aoFechar) { Text("Cancelar") } },
    )
}
