package com.huryel.novelas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.huryel.novelas.ui.AppNavegacao
import com.huryel.novelas.ui.theme.NovelasTheme
import com.huryel.novelas.ui.theme.TemaLeitura

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Fase A: tema guardado só em memória. Na Fase B passa a ser salvo no aparelho.
            var tema by rememberSaveable { mutableStateOf(TemaLeitura.OLED) }
            NovelasTheme(tema) {
                AppNavegacao(temaAtual = tema, aoMudarTema = { tema = it })
            }
        }
    }
}
