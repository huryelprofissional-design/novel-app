package com.huryel.novelas.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.huryel.novelas.ui.theme.LocalPaleta
import com.huryel.novelas.ui.theme.TemaLeitura

/** Dados de exemplo só para a Fase A. Na Fase B vêm do banco local. */
private data class ObraDemo(val id: Int, val titulo: String, val status: String, val cor: Color)

private val obrasDemo = listOf(
    ObraDemo(1, "A Torre de Cinzas", "Lendo · 44%", Color(0xFF3B2A4A)),
    ObraDemo(2, "Herdeiro do Vazio", "Escrevendo · 38 caps", Color(0xFF1F3B3A)),
    ObraDemo(3, "Lâmina Lunar", "Lendo · 41%", Color(0xFF4A2420)),
    ObraDemo(4, "Mil Caminhos do Céu", "Concluída", Color(0xFF23283F)),
)

private data class Aba(val rota: String, val rotulo: String, val icone: ImageVector)

private val abas = listOf(
    Aba("biblioteca", "Biblioteca", Icons.Filled.Home),
    Aba("escrever", "Escrever", Icons.Filled.Edit),
    Aba("buscar", "Buscar", Icons.Filled.Search),
    Aba("ajustes", "Ajustes", Icons.Filled.Settings),
)

@Composable
fun AppNavegacao(temaAtual: TemaLeitura, aoMudarTema: (TemaLeitura) -> Unit) {
    val nav = rememberNavController()
    val atual by nav.currentBackStackEntryAsState()
    val rota = atual?.destination?.route
    val mostrarBarra = abas.any { it.rota == rota }
    val p = LocalPaleta.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (mostrarBarra) {
                NavigationBar(containerColor = p.superficie) {
                    abas.forEach { aba ->
                        NavigationBarItem(
                            selected = rota == aba.rota,
                            onClick = {
                                nav.navigate(aba.rota) {
                                    popUpTo("biblioteca") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(aba.icone, contentDescription = null) },
                            label = { Text(aba.rotulo) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = p.destaque,
                                selectedTextColor = p.destaque,
                                indicatorColor = p.borda,
                                unselectedIconColor = p.textoSuave,
                                unselectedTextColor = p.textoSuave,
                            ),
                        )
                    }
                }
            }
        },
    ) { margem ->
        NavHost(nav, startDestination = "biblioteca", modifier = Modifier.padding(margem)) {
            composable("biblioteca") { TelaBiblioteca(nav) }
            composable("escrever") { TelaEmBreve("Escrever", "Suas obras em andamento aparecem aqui (Fase E).") }
            composable("buscar") { TelaEmBreve("Buscar", "Busca em todas as obras (Fase F).") }
            composable("ajustes") { TelaAjustes(temaAtual, aoMudarTema, nav) }
            composable("novel/{id}") { e ->
                val id = e.arguments?.getString("id")?.toIntOrNull() ?: 1
                TelaNovel(obrasDemo.first { it.id == id }, nav)
            }
            composable("leitor") { TelaLeitorDemo(nav) }
            composable("backup") { TelaEmBreve("Importar e backup", "TXT, EPUB e backups (Fases C e G).", nav) }
        }
    }
}

@Composable
private fun TelaBiblioteca(nav: NavHostController) {
    val p = LocalPaleta.current
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(20.dp))
            Text("BIBLIOTECA", style = MaterialTheme.typography.labelSmall, color = p.textoSuave)
            Text("Suas obras", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(16.dp))
            CartaoContinuar(obrasDemo[0]) { nav.navigate("leitor") }
            Spacer(Modifier.height(20.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(bottom = 96.dp),
            ) {
                items(obrasDemo, key = { it.id }) { obra ->
                    Column(Modifier.clickable { nav.navigate("novel/${obra.id}") }) {
                        Capa(obra, Modifier.fillMaxWidth().height(150.dp))
                        Spacer(Modifier.height(6.dp))
                        Text(obra.status, fontSize = 12.sp, color = p.textoSuave)
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { nav.navigate("backup") },
            containerColor = p.destaque,
            contentColor = p.sobreDestaque,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
        ) { Icon(Icons.Filled.Add, contentDescription = "Importar ou criar obra") }
    }
}

@Composable
private fun Capa(obra: ObraDemo, modifier: Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(12.dp)).background(obra.cor).padding(10.dp),
        contentAlignment = Alignment.BottomStart,
    ) {
        Text(obra.titulo, style = MaterialTheme.typography.headlineSmall.copy(fontSize = 14.sp, lineHeight = 16.sp), color = Color(0xFFF5EEE2))
    }
}

@Composable
private fun CartaoContinuar(obra: ObraDemo, aoAbrir: () -> Unit) {
    val p = LocalPaleta.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(p.superficie)
            .border(1.dp, p.borda, RoundedCornerShape(22.dp)).clickable(onClick = aoAbrir).padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Capa(obra, Modifier.width(80.dp).height(116.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("CONTINUAR LENDO", style = MaterialTheme.typography.labelSmall, color = p.destaque)
            Text(obra.titulo, style = MaterialTheme.typography.headlineSmall.copy(fontSize = 20.sp))
            Text("Cap. 214 · O Juramento", fontSize = 13.sp, color = p.textoSuave)
            Spacer(Modifier.weight(1f))
            LinearProgressIndicator(
                progress = { 0.63f },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = p.destaque, trackColor = p.borda, drawStopIndicator = {},
            )
        }
    }
}

@Composable
private fun Topo(titulo: String, nav: NavHostController?) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (nav != null) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
            }
        }
        Text(titulo, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun TelaNovel(obra: ObraDemo, nav: NavHostController) {
    val p = LocalPaleta.current
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Box(Modifier.fillMaxWidth().height(220.dp).background(obra.cor)) {
                Topo("", nav)
                Text(obra.titulo, style = MaterialTheme.typography.displaySmall.copy(fontSize = 30.sp),
                    color = Color(0xFFF5EEE2), modifier = Modifier.align(Alignment.BottomStart).padding(20.dp))
            }
            Button(
                onClick = { nav.navigate("leitor") },
                colors = ButtonDefaults.buttonColors(containerColor = p.destaque, contentColor = p.sobreDestaque),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(20.dp).height(52.dp),
            ) { Text("Continuar lendo", fontWeight = FontWeight.Bold) }
            Text("Capítulos", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp))
        }
        items((1..30).toList()) { n ->
            Row(Modifier.fillMaxWidth().clickable { nav.navigate("leitor") }.padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text("$n", color = p.textoSuave, modifier = Modifier.width(40.dp))
                Text("Capítulo de exemplo $n")
            }
        }
    }
}

@Composable
private fun TelaLeitorDemo(nav: NavHostController) {
    val p = LocalPaleta.current
    val paragrafos = remember {
        List(200) { i -> "Parágrafo ${i + 1}. Texto sintético de demonstração: a chuva tinha parado havia horas, mas as pedras da cidade ainda guardavam o brilho úmido da noite, e cada passo na escada soava como uma dívida antiga sendo contada." }
    }
    var controles by remember { mutableStateOf(true) }
    Box(Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { controles = !controles }) {
        LazyColumn(contentPadding = PaddingValues(horizontal = 26.dp, vertical = 72.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item { Text("Capítulo de demonstração", style = MaterialTheme.typography.displaySmall.copy(fontSize = 28.sp)) }
            items(paragrafos) { Text(it, style = MaterialTheme.typography.bodyLarge) }
        }
        if (controles) {
            Surface(color = p.superficie.copy(alpha = 0.96f), modifier = Modifier.fillMaxWidth()) { Topo("Leitor (prévia da Fase D)", nav) }
        }
    }
}

@Composable
private fun TelaAjustes(temaAtual: TemaLeitura, aoMudarTema: (TemaLeitura) -> Unit, nav: NavHostController) {
    val p = LocalPaleta.current
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Ajustes", style = MaterialTheme.typography.displaySmall)
        Text("TEMA", style = MaterialTheme.typography.labelSmall, color = p.textoSuave)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TemaLeitura.entries.forEach { t ->
                val sel = t == temaAtual
                Box(
                    Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(16.dp)).background(t.paleta.fundo)
                        .border(if (sel) 2.dp else 1.dp, if (sel) p.destaque else p.borda, RoundedCornerShape(16.dp))
                        .clickable { aoMudarTema(t) },
                    contentAlignment = Alignment.Center,
                ) { Text(t.paleta.nome, color = t.paleta.texto, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
        }
        OutlinedButton(onClick = { nav.navigate("backup") }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
            Text("Importar e backup")
        }
        Text("Versão 0.1 · Fase A", fontSize = 12.sp, color = p.textoSuave)
    }
}

@Composable
private fun TelaEmBreve(titulo: String, texto: String, nav: NavHostController? = null) {
    val p = LocalPaleta.current
    Column(Modifier.fillMaxSize()) {
        if (nav != null) Topo(titulo, nav)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (nav == null) Text(titulo, style = MaterialTheme.typography.displaySmall)
            Text(texto, color = p.textoSuave)
        }
    }
}
